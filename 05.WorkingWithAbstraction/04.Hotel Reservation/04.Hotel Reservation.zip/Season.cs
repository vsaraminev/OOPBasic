﻿public enum Season
{
    Autumn = 1,
    Spring,
    Winter,
    Summer
}
