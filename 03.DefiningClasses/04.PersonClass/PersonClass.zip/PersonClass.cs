﻿using System;

public class PersonClass
{
    public static void Main()
    {

    }
}

