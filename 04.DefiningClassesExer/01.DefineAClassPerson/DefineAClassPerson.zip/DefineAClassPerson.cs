﻿using System;

public class DefineAClassPerson
{
    public static void Main()
    {
        var Pesho = new Person();

        Pesho.Name = "Pesho";
        Pesho.Age = 20;
    }
}

