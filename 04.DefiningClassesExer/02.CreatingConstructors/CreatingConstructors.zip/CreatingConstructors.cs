﻿public class CreatingConstructors
{
    public static void Main()
    {

    }
}

